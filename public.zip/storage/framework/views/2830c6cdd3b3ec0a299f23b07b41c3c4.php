<div class="flex flex-col l:flex-row   bg-sky-100 w-full my-0 py-0 fullscreen pt-2 lg:px-2 px-1">  

      <div class="grid lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2  grid-cols-1 gap-8">

          <div class="border-4 p-12 shadow-md border-green-500">Miembros</div>
          <div class="border-4 p-12 shadow-md border-blue-500">Hijos</div>
          <div class="border-4 p-12 shadow-md border-yellow-500">Beneficios</div>
          <div class="border-4 p-12 shadow-md border-red-500">Beneficios Vigentes</div>


      </div>
  

    


</div> 
<?php /**PATH C:\xampp\htdocs\soeesit\resources\views/livewire/admin/dashboard.blade.php ENDPATH**/ ?>