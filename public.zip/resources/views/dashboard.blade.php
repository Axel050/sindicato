<x-app-layout>     
    <x-slot name="headerT">
    Dashboard
  </x-slot>

  @livewire('admin.dashboard')


</x-app-layout>
