<x-app-layout>     
    <x-slot name="headerT">
    Condicion de Miembro
  </x-slot>

  @livewire('admin.tablas.condiciones.index')


</x-app-layout>
