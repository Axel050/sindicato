<x-app-layout>     
    <x-slot name="headerT">
    Sectores
  </x-slot>

  @livewire('admin.tablas.sectores.index')


</x-app-layout>
