<x-app-layout>     
    <x-slot name="headerT">
    Empresas
  </x-slot>

  @livewire('admin.tablas.empresas.index')


</x-app-layout>
