<x-app-layout>     
    <x-slot name="headerT">
    Gremios
  </x-slot>

  @livewire('admin.tablas.gremios.index')


</x-app-layout>
